# TCP-Server-Client-Communication
A simple TCP based application created on Python using socket programming that allows for three concurrent users to connect and send messages to a server host.
